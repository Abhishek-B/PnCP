
%% creating bound entangled state given in the article

I3 = eye(3);

% Building the state vectors given in the article
phi = (1/3)*( kron(I3(:,1),I3(:,1))+kron(I3(:,2),I3(:,2))+kron(I3(:,3),I3(:,3)) )*( kron(I3(:,1),I3(:,1))+kron(I3(:,2),I3(:,2))+kron(I3(:,3),I3(:,3)) )';

sigplus = (1/3)*( kron(I3(:,1),I3(:,2))*kron(I3(:,1),I3(:,2))' + kron(I3(:,2),I3(:,3))*kron(I3(:,2),I3(:,3))' + kron(I3(:,3),I3(:,1))*kron(I3(:,3),I3(:,1))');
sigminus = (1/3)*( kron(I3(:,2),I3(:,1))*kron(I3(:,2),I3(:,1))' + kron(I3(:,3),I3(:,2))*kron(I3(:,3),I3(:,2))' + kron(I3(:,1),I3(:,3))*kron(I3(:,1),I3(:,3))');

% defining the state gamma
gamma = (2/7)*phi + (4/7)*sigplus + (1/7)*sigminus;



%% Running PnCP Entagnlement Check

tic;
Output = Ent_PnCP(3,3,3,gamma,5);
Phi = Output{1,1};
M = Output{1,2};
timetaken = toc;

%%
disp("The ampliation is:")
disp(sym(M))
disp("with eigenvalues:")
disp(eig(M)')

%% Outputting Phi

disp(sym(Phi{1,1}))
disp(sym(Phi{2,2}))
disp(sym(Phi{3,3}))

disp(sym(Phi{1,2}+Phi{2,1}))
disp(sym(Phi{1,3}+Phi{3,1}))
disp(sym(Phi{2,3}+Phi{3,2}))